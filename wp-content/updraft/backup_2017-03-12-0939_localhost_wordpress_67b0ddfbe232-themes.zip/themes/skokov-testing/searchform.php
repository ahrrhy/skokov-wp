<form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ) ?>"  class="aside-search-form">
    <input type="search" class="search-input" name="aside-search" placeholder="Search">
    <label for="search-submit" class="label-submit"><i class="fa fa-search search-ico" aria-hidden="true"></i><input id="search-submit" type="submit" class="aside-search-submit" name="search-submit" value=""></label>
</form>